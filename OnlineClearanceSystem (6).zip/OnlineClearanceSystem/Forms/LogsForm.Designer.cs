namespace OnlineClearanceSystem.Forms
{
    partial class LogsForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.dgvLogs = new System.Windows.Forms.DataGridView();
            this.LogIdColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LogUserIdColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LogActionColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LogDescriptionColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LogDateCreatedColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLogs)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(12, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(120, 25);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Activity Logs";
            // 
            // dgvLogs
            // 
            this.dgvLogs.AllowUserToAddRows = false;
            this.dgvLogs.AllowUserToDeleteRows = false;
            this.dgvLogs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLogs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.LogIdColumn,
            this.LogUserIdColumn,
            this.LogActionColumn,
            this.LogDescriptionColumn,
            this.LogDateCreatedColumn});
            this.dgvLogs.Location = new System.Drawing.Point(12, 50);
            this.dgvLogs.Name = "dgvLogs";
            this.dgvLogs.ReadOnly = true;
            this.dgvLogs.RowTemplate.Height = 25;
            this.dgvLogs.Size = new System.Drawing.Size(760, 388);
            this.dgvLogs.TabIndex = 1;
            // 
            // LogIdColumn
            // 
            this.LogIdColumn.HeaderText = "ID";
            this.LogIdColumn.Name = "LogIdColumn";
            this.LogIdColumn.ReadOnly = true;
            this.LogIdColumn.Width = 50;
            // 
            // LogUserIdColumn
            // 
            this.LogUserIdColumn.HeaderText = "User ID";
            this.LogUserIdColumn.Name = "LogUserIdColumn";
            this.LogUserIdColumn.ReadOnly = true;
            this.LogUserIdColumn.Width = 70;
            // 
            // LogActionColumn
            // 
            this.LogActionColumn.HeaderText = "Action";
            this.LogActionColumn.Name = "LogActionColumn";
            this.LogActionColumn.ReadOnly = true;
            this.LogActionColumn.Width = 150;
            // 
            // LogDescriptionColumn
            // 
            this.LogDescriptionColumn.HeaderText = "Description";
            this.LogDescriptionColumn.Name = "LogDescriptionColumn";
            this.LogDescriptionColumn.ReadOnly = true;
            this.LogDescriptionColumn.Width = 250;
            // 
            // LogDateCreatedColumn
            // 
            this.LogDateCreatedColumn.HeaderText = "Date Created";
            this.LogDateCreatedColumn.Name = "LogDateCreatedColumn";
            this.LogDateCreatedColumn.ReadOnly = true;
            this.LogDateCreatedColumn.Width = 150;
            // 
            // LogsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 450);
            this.Controls.Add(this.dgvLogs);
            this.Controls.Add(this.lblTitle);
            this.Name = "LogsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Activity Logs";
            ((System.ComponentModel.ISupportInitialize)(this.dgvLogs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.DataGridView dgvLogs;
        private System.Windows.Forms.DataGridViewTextBoxColumn LogIdColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn LogUserIdColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn LogActionColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn LogDescriptionColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn LogDateCreatedColumn;
    }
}

using System;
using System.Windows.Forms;
using OnlineClearanceSystem.Models;

namespace OnlineClearanceSystem.Forms
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
            LoadDashboardBasedOnRole();
        }

        private void LoadDashboardBasedOnRole()
        {
            if (Session.CurrentUser == null)
            {
                MessageBox.Show("Session expired or no user logged in.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
                this.Close();
                return;
            }

            lblWelcome.Text = $"Welcome, {Session.CurrentUser.FullName} ({Session.CurrentUser.Role})!";

            // Hide all panels initially
            pnlStudent.Visible = false;
            pnlOffice.Visible = false;
            pnlAdmin.Visible = false;

            switch (Session.CurrentUser.Role)
            {
                case "Student":
                    pnlStudent.Visible = true;
                    break;
                case "Admin":
                    pnlAdmin.Visible = true;
                    break;
                default: // Assume it's an office role
                    pnlOffice.Visible = true;
                    break;
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            OnlineClearanceSystem.Data.Logger.Log(Session.CurrentUser, "Logout", $"User {Session.CurrentUser.Username} logged out.");
            Session.CurrentUser = null;
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Close();
        }

        // Student Panel Buttons
        private void btnSubmitRequest_Click(object sender, EventArgs e)
        {
            RequestForm requestForm = new RequestForm();
            requestForm.ShowDialog();
            // Refresh student dashboard if needed after request submission
        }

        private void btnManageSubjects_Click(object sender, EventArgs e)
        {
            // Open Subject Management Form
        }

        // Office Panel Buttons
        private void btnApproveRequests_Click(object sender, EventArgs e)
        {
            ApprovalForm approvalForm = new ApprovalForm();
            approvalForm.ShowDialog();
            // Refresh office dashboard if needed after approval
        }

        // Admin Panel Buttons
        private void btnViewLogs_Click(object sender, EventArgs e)
        {
            LogsForm logsForm = new LogsForm();
            logsForm.ShowDialog();
        }

        private void btnManageUsers_Click(object sender, EventArgs e)
        {
            AdminForm adminForm = new AdminForm();
            adminForm.ShowDialog();
        }
    }
}

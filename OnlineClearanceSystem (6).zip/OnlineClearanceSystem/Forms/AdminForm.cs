using System;
using System.Data.OleDb;
using System.Windows.Forms;
using OnlineClearanceSystem.Data;
using OnlineClearanceSystem.Models;

namespace OnlineClearanceSystem.Forms
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
            LoadUsers();
        }

        private void LoadUsers()
        {
            try
            {
                dgvUsers.Rows.Clear();
                using (OleDbDataReader reader = Db.GetAllUsers())
                {
                    while (reader.Read())
                    {
                        dgvUsers.Rows.Add(reader["Id"], reader["Username"], reader["Role"], reader["FullName"], reader["Course"]);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading users: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Logger.Log(Session.CurrentUser, "Error", $"Error loading users: {ex.Message}");
            }
        }

        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            if (dgvUsers.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a user to delete.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Are you sure you want to delete this user?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                int userId = Convert.ToInt32(dgvUsers.SelectedRows[0].Cells["UserIdColumn"].Value);
                try
                {
                    int result = Db.DeleteUser(userId);
                    if (result > 0)
                    {
                        MessageBox.Show("User deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Logger.Log(Session.CurrentUser, "Delete User", $"User {userId} deleted by {Session.CurrentUser.Username}.");
                        LoadUsers();
                    }
                    else
                    {
                        MessageBox.Show("Failed to delete user.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting user: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Logger.Log(Session.CurrentUser, "Error", $"Error deleting user {userId}: {ex.Message}");
                }
            }
        }
    }
}

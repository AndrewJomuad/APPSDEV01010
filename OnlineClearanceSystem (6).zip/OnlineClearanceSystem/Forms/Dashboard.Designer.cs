namespace OnlineClearanceSystem.Forms
{
    partial class Dashboard
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.pnlStudent = new System.Windows.Forms.Panel();
            this.btnManageSubjects = new System.Windows.Forms.Button();
            this.btnSubmitRequest = new System.Windows.Forms.Button();
            this.pnlOffice = new System.Windows.Forms.Panel();
            this.btnApproveRequests = new System.Windows.Forms.Button();
            this.pnlAdmin = new System.Windows.Forms.Panel();
            this.btnManageUsers = new System.Windows.Forms.Button();
            this.btnViewLogs = new System.Windows.Forms.Button();
            this.pnlStudent.SuspendLayout();
            this.pnlOffice.SuspendLayout();
            this.pnlAdmin.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblWelcome.Location = new System.Drawing.Point(12, 9);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(82, 21);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "Welcome!";
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(697, 9);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 23);
            this.btnLogout.TabIndex = 1;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // pnlStudent
            // 
            this.pnlStudent.Controls.Add(this.btnManageSubjects);
            this.pnlStudent.Controls.Add(this.btnSubmitRequest);
            this.pnlStudent.Location = new System.Drawing.Point(12, 50);
            this.pnlStudent.Name = "pnlStudent";
            this.pnlStudent.Size = new System.Drawing.Size(760, 388);
            this.pnlStudent.TabIndex = 2;
            // 
            // btnManageSubjects
            // 
            this.btnManageSubjects.Location = new System.Drawing.Point(15, 50);
            this.btnManageSubjects.Name = "btnManageSubjects";
            this.btnManageSubjects.Size = new System.Drawing.Size(150, 30);
            this.btnManageSubjects.TabIndex = 1;
            this.btnManageSubjects.Text = "Manage Subjects";
            this.btnManageSubjects.UseVisualStyleBackColor = true;
            this.btnManageSubjects.Click += new System.EventHandler(this.btnManageSubjects_Click);
            // 
            // btnSubmitRequest
            // 
            this.btnSubmitRequest.Location = new System.Drawing.Point(15, 15);
            this.btnSubmitRequest.Name = "btnSubmitRequest";
            this.btnSubmitRequest.Size = new System.Drawing.Size(150, 30);
            this.btnSubmitRequest.TabIndex = 0;
            this.btnSubmitRequest.Text = "Submit Clearance Request";
            this.btnSubmitRequest.UseVisualStyleBackColor = true;
            this.btnSubmitRequest.Click += new System.EventHandler(this.btnSubmitRequest_Click);
            // 
            // pnlOffice
            // 
            this.pnlOffice.Controls.Add(this.btnApproveRequests);
            this.pnlOffice.Location = new System.Drawing.Point(12, 50);
            this.pnlOffice.Name = "pnlOffice";
            this.pnlOffice.Size = new System.Drawing.Size(760, 388);
            this.pnlOffice.TabIndex = 3;
            // 
            // btnApproveRequests
            // 
            this.btnApproveRequests.Location = new System.Drawing.Point(15, 15);
            this.btnApproveRequests.Name = "btnApproveRequests";
            this.btnApproveRequests.Size = new System.Drawing.Size(150, 30);
            this.btnApproveRequests.TabIndex = 0;
            this.btnApproveRequests.Text = "Approve Requests";
            this.btnApproveRequests.UseVisualStyleBackColor = true;
            this.btnApproveRequests.Click += new System.EventHandler(this.btnApproveRequests_Click);
            // 
            // pnlAdmin
            // 
            this.pnlAdmin.Controls.Add(this.btnManageUsers);
            this.pnlAdmin.Controls.Add(this.btnViewLogs);
            this.pnlAdmin.Location = new System.Drawing.Point(12, 50);
            this.pnlAdmin.Name = "pnlAdmin";
            this.pnlAdmin.Size = new System.Drawing.Size(760, 388);
            this.pnlAdmin.TabIndex = 4;
            // 
            // btnManageUsers
            // 
            this.btnManageUsers.Location = new System.Drawing.Point(15, 50);
            this.btnManageUsers.Name = "btnManageUsers";
            this.btnManageUsers.Size = new System.Drawing.Size(150, 30);
            this.btnManageUsers.TabIndex = 1;
            this.btnManageUsers.Text = "Manage Users";
            this.btnManageUsers.UseVisualStyleBackColor = true;
            this.btnManageUsers.Click += new System.EventHandler(this.btnManageUsers_Click);
            // 
            // btnViewLogs
            // 
            this.btnViewLogs.Location = new System.Drawing.Point(15, 15);
            this.btnViewLogs.Name = "btnViewLogs";
            this.btnViewLogs.Size = new System.Drawing.Size(150, 30);
            this.btnViewLogs.TabIndex = 0;
            this.btnViewLogs.Text = "View Logs";
            this.btnViewLogs.UseVisualStyleBackColor = true;
            this.btnViewLogs.Click += new System.EventHandler(this.btnViewLogs_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 450);
            this.Controls.Add(this.pnlAdmin);
            this.Controls.Add(this.pnlOffice);
            this.Controls.Add(this.pnlStudent);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.lblWelcome);
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.pnlStudent.ResumeLayout(false);
            this.pnlOffice.ResumeLayout(false);
            this.pnlAdmin.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Panel pnlStudent;
        private System.Windows.Forms.Button btnSubmitRequest;
        private System.Windows.Forms.Button btnManageSubjects;
        private System.Windows.Forms.Panel pnlOffice;
        private System.Windows.Forms.Button btnApproveRequests;
        private System.Windows.Forms.Panel pnlAdmin;
        private System.Windows.Forms.Button btnManageUsers;
        private System.Windows.Forms.Button btnViewLogs;
    }
}

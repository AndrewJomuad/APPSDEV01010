using System;
using System.Data.OleDb;
using System.Windows.Forms;
using OnlineClearanceSystem.Data;
using OnlineClearanceSystem.Models;

namespace OnlineClearanceSystem.Forms
{
    public partial class ApprovalForm : Form
    {
        public ApprovalForm()
        {
            InitializeComponent();
            LoadPendingRequests();
        }

        private void LoadPendingRequests()
        {
            if (Session.CurrentUser == null || string.IsNullOrEmpty(Session.CurrentUser.Role))
            {
                MessageBox.Show("Invalid session or role.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }

            try
            {
                dgvRequests.Rows.Clear();
                using (OleDbDataReader reader = Db.GetClearanceRequestsForOffice(Session.CurrentUser.Role))
                {
                    while (reader.Read())
                    {
                        dgvRequests.Rows.Add(reader["Id"], reader["FullName"], reader["DateFiled"], reader["Status"]);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading pending requests: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Logger.Log(Session.CurrentUser, "Error", $"Error loading pending requests for {Session.CurrentUser.Role}: {ex.Message}");
            }
        }

        private void dgvRequests_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int requestId = Convert.ToInt32(dgvRequests.Rows[e.RowIndex].Cells["RequestIdColumn"].Value);
                LoadRequestSteps(requestId);
            }
        }

        private void LoadRequestSteps(int requestId)
        {
            try
            {
                dgvSteps.Rows.Clear();
                using (OleDbDataReader reader = Db.GetClearanceStepsByRequestId(requestId))
                {
                    while (reader.Read())
                    {
                        dgvSteps.Rows.Add(reader["Id"], reader["Office"], reader["Status"], reader["Remarks"]);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading request steps: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Logger.Log(Session.CurrentUser, "Error", $"Error loading steps for request {requestId}: {ex.Message}");
            }
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {
            UpdateClearanceStepStatus("Approved");
        }

        private void btnReject_Click(object sender, EventArgs e)
        {
            UpdateClearanceStepStatus("Rejected");
        }

        private void UpdateClearanceStepStatus(string status)
        {
            if (dgvSteps.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a step to approve or reject.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int stepId = Convert.ToInt32(dgvSteps.SelectedRows[0].Cells["StepIdColumn"].Value);
            string remarks = txtRemarks.Text.Trim();

            try
            {
                int result = Db.UpdateClearanceStep(stepId, status, remarks);
                if (result > 0)
                {
                    MessageBox.Show($"Step {status} successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Logger.Log(Session.CurrentUser, $"{status} Step", $"Step {stepId} {status} by {Session.CurrentUser.Username}.");
                    LoadRequestSteps(Convert.ToInt32(dgvRequests.SelectedRows[0].Cells["RequestIdColumn"].Value));
                    CheckClearanceRequestStatus(Convert.ToInt32(dgvRequests.SelectedRows[0].Cells["RequestIdColumn"].Value));
                }
                else
                {
                    MessageBox.Show($"Failed to {status.ToLower()} step.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error {status.ToLower()} step: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Logger.Log(Session.CurrentUser, "Error", $"Error {status.ToLower()} step {stepId}: {ex.Message}");
            }
        }

        private void CheckClearanceRequestStatus(int requestId)
        {
            bool allStepsApproved = true;
            bool anyStepRejected = false;

            using (OleDbDataReader reader = Db.GetClearanceStepsByRequestId(requestId))
            {
                while (reader.Read())
                {
                    string status = reader["Status"].ToString();
                    if (status == "Rejected")
                    {
                        anyStepRejected = true;
                        break;
                    }
                    if (status != "Approved")
                    {
                        allStepsApproved = false;
                    }
                }
            }

            if (anyStepRejected)
            {
                Db.UpdateClearanceRequestStatus(requestId, "Rejected");
                Logger.Log(Session.CurrentUser, "Clearance Request Status Update", $"Clearance Request {requestId} status updated to Rejected.");
            }
            else if (allStepsApproved)
            {
                // Check if all subjects are cleared for the user associated with this request
                int userId = 0;
                string userQuery = "SELECT UserId FROM ClearanceRequests WHERE Id = ?";
                OleDbParameter[] userParams = { new OleDbParameter("@p1", requestId) };
                using (OleDbDataReader requestReader = Db.ExecuteReader(userQuery, userParams))
                {
                    if (requestReader.Read())
                    {
                        userId = Convert.ToInt32(requestReader["UserId"]);
                    }
                }

                bool allSubjectsCleared = true;
                using (OleDbDataReader subjectReader = Db.GetSubjectsByUserId(userId))
                {
                    while (subjectReader.Read())
                    {
                        if (subjectReader["Status"].ToString() != "Cleared")
                        {
                            allSubjectsCleared = false;
                            break;
                        }
                    }
                }

                if (allSubjectsCleared)
                {
                    Db.UpdateClearanceRequestStatus(requestId, "Approved");
                    Logger.Log(Session.CurrentUser, "Clearance Request Status Update", $"Clearance Request {requestId} status updated to Approved.");
                }
                else
                {
                    // If all steps are approved but subjects are not cleared, keep as pending or set a specific status
                    // For now, we'll assume it stays 'Pending' until subjects are cleared.
                    // Or, we could explicitly set it to 'Pending - Subjects Not Cleared'
                    Db.UpdateClearanceRequestStatus(requestId, "Pending - Subjects Not Cleared");
                    Logger.Log(Session.CurrentUser, "Clearance Request Status Update", $"Clearance Request {requestId} status updated to Pending - Subjects Not Cleared (steps approved).");
                }
            }
            LoadPendingRequests(); // Refresh the main requests list
        }
    }
}

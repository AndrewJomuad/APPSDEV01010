namespace OnlineClearanceSystem.Forms
{
    partial class RequestForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.dgvSubjects = new System.Windows.Forms.DataGridView();
            this.SubjectIdColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SubjectNameColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StatusColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblSubjects = new System.Windows.Forms.Label();
            this.txtSubjectName = new System.Windows.Forms.TextBox();
            this.btnAddSubject = new System.Windows.Forms.Button();
            this.btnSubmitClearance = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSubjects)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(12, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(232, 25);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Submit Clearance Request";
            // 
            // dgvSubjects
            // 
            this.dgvSubjects.AllowUserToAddRows = false;
            this.dgvSubjects.AllowUserToDeleteRows = false;
            this.dgvSubjects.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSubjects.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SubjectIdColumn,
            this.SubjectNameColumn,
            this.StatusColumn});
            this.dgvSubjects.Location = new System.Drawing.Point(12, 100);
            this.dgvSubjects.Name = "dgvSubjects";
            this.dgvSubjects.ReadOnly = true;
            this.dgvSubjects.RowTemplate.Height = 25;
            this.dgvSubjects.Size = new System.Drawing.Size(400, 200);
            this.dgvSubjects.TabIndex = 1;
            // 
            // SubjectIdColumn
            // 
            this.SubjectIdColumn.HeaderText = "ID";
            this.SubjectIdColumn.Name = "SubjectIdColumn";
            this.SubjectIdColumn.ReadOnly = true;
            this.SubjectIdColumn.Visible = false;
            // 
            // SubjectNameColumn
            // 
            this.SubjectNameColumn.HeaderText = "Subject Name";
            this.SubjectNameColumn.Name = "SubjectNameColumn";
            this.SubjectNameColumn.ReadOnly = true;
            this.SubjectNameColumn.Width = 200;
            // 
            // StatusColumn
            // 
            this.StatusColumn.HeaderText = "Status";
            this.StatusColumn.Name = "StatusColumn";
            this.StatusColumn.ReadOnly = true;
            // 
            // lblSubjects
            // 
            this.lblSubjects.AutoSize = true;
            this.lblSubjects.Location = new System.Drawing.Point(12, 70);
            this.lblSubjects.Name = "lblSubjects";
            this.lblSubjects.Size = new System.Drawing.Size(55, 15);
            this.lblSubjects.TabIndex = 2;
            this.lblSubjects.Text = "Subjects:";
            // 
            // txtSubjectName
            // 
            this.txtSubjectName.Location = new System.Drawing.Point(12, 310);
            this.txtSubjectName.Name = "txtSubjectName";
            this.txtSubjectName.Size = new System.Drawing.Size(250, 23);
            this.txtSubjectName.TabIndex = 3;
            // 
            // btnAddSubject
            // 
            this.btnAddSubject.Location = new System.Drawing.Point(268, 309);
            this.btnAddSubject.Name = "btnAddSubject";
            this.btnAddSubject.Size = new System.Drawing.Size(144, 23);
            this.btnAddSubject.TabIndex = 4;
            this.btnAddSubject.Text = "Add Subject";
            this.btnAddSubject.UseVisualStyleBackColor = true;
            this.btnAddSubject.Click += new System.EventHandler(this.btnAddSubject_Click);
            // 
            // btnSubmitClearance
            // 
            this.btnSubmitClearance.Location = new System.Drawing.Point(12, 350);
            this.btnSubmitClearance.Name = "btnSubmitClearance";
            this.btnSubmitClearance.Size = new System.Drawing.Size(150, 30);
            this.btnSubmitClearance.TabIndex = 5;
            this.btnSubmitClearance.Text = "Submit Clearance Request";
            this.btnSubmitClearance.UseVisualStyleBackColor = true;
            this.btnSubmitClearance.Click += new System.EventHandler(this.btnSubmitClearance_Click);
            // 
            // RequestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 400);
            this.Controls.Add(this.btnSubmitClearance);
            this.Controls.Add(this.btnAddSubject);
            this.Controls.Add(this.txtSubjectName);
            this.Controls.Add(this.lblSubjects);
            this.Controls.Add(this.dgvSubjects);
            this.Controls.Add(this.lblTitle);
            this.Name = "RequestForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Submit Clearance Request";
            ((System.ComponentModel.ISupportInitialize)(this.dgvSubjects)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.DataGridView dgvSubjects;
        private System.Windows.Forms.Label lblSubjects;
        private System.Windows.Forms.TextBox txtSubjectName;
        private System.Windows.Forms.Button btnAddSubject;
        private System.Windows.Forms.Button btnSubmitClearance;
        private System.Windows.Forms.DataGridViewTextBoxColumn SubjectIdColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn SubjectNameColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn StatusColumn;
    }
}

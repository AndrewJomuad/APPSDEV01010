using System;
using System.Windows.Forms;
using OnlineClearanceSystem.Data;
using OnlineClearanceSystem.Models;

namespace OnlineClearanceSystem.Forms
{
    public partial class RequestForm : Form
    {
        public RequestForm()
        {
            InitializeComponent();
            LoadSubjects();
        }

        private void LoadSubjects()
        {
            try
            {
                dgvSubjects.Rows.Clear();
                using (System.Data.OleDb.OleDbDataReader reader = Db.GetSubjectsByUserId(Session.CurrentUser.Id))
                {
                    while (reader.Read())
                    {
                        dgvSubjects.Rows.Add(reader["Id"], reader["SubjectName"], reader["Status"]);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading subjects: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Logger.Log(Session.CurrentUser, "Error", $"Error loading subjects: {ex.Message}");
            }
        }

        private void btnAddSubject_Click(object sender, EventArgs e)
        {
            string subjectName = txtSubjectName.Text.Trim();
            if (string.IsNullOrWhiteSpace(subjectName))
            {
                MessageBox.Show("Please enter a subject name.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                int result = Db.InsertSubject(Session.CurrentUser.Id, subjectName);
                if (result > 0)
                {
                    MessageBox.Show("Subject added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Logger.Log(Session.CurrentUser, "Add Subject", $"Subject '{subjectName}' added by {Session.CurrentUser.Username}.");
                    txtSubjectName.Clear();
                    LoadSubjects();
                }
                else
                {
                    MessageBox.Show("Failed to add subject.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding subject: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Logger.Log(Session.CurrentUser, "Error", $"Error adding subject '{subjectName}': {ex.Message}");
            }
        }

        private void btnSubmitClearance_Click(object sender, EventArgs e)
        {
            if (dgvSubjects.Rows.Count == 0)
            {
                MessageBox.Show("Please add at least one subject before submitting a clearance request.", "Submission Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check if all subjects are cleared
            foreach (DataGridViewRow row in dgvSubjects.Rows)
            {
                if (row.Cells["StatusColumn"].Value != null && row.Cells["StatusColumn"].Value.ToString() != "Cleared")
                {
                    MessageBox.Show("All subjects must be 'Cleared' before submitting a clearance request.", "Submission Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            try
            {
                int rowsAffected = Db.InsertClearanceRequest(Session.CurrentUser.Id);
                if (rowsAffected > 0)
                {
                    int requestId = Db.GetLastClearanceRequestId(); // Get the last inserted ID

                    // Auto-create steps: Library → Accounting → Registrar → SAO → Dean
                    string[] offices = { "Library", "Accounting", "Registrar", "SAO", "Dean" };
                    foreach (string office in offices)
                    {
                        Db.InsertClearanceStep(requestId, office, "Pending");
                    }

                    MessageBox.Show("Clearance request submitted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Logger.Log(Session.CurrentUser, "Submit Clearance Request", $"Clearance request {requestId} submitted by {Session.CurrentUser.Username}.");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Failed to submit clearance request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error submitting clearance request: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Logger.Log(Session.CurrentUser, "Error", $"Error submitting clearance request: {ex.Message}");
            }
        }
    }
}

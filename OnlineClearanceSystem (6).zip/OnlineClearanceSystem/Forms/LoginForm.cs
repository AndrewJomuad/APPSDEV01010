using System;
using System.Data.OleDb;
using System.Windows.Forms;
using OnlineClearanceSystem.Data;
using OnlineClearanceSystem.Models;

namespace OnlineClearanceSystem.Forms
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter both username and password.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (OleDbDataReader reader = Db.GetUser(username, password))
                {
                    if (reader.Read())
                    {
                        Session.CurrentUser = new User
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Username = reader["Username"].ToString(),
                            Role = reader["Role"].ToString(),
                            FullName = reader["FullName"].ToString(),
                            Course = reader["Course"].ToString()
                        };

                        Logger.Log(Session.CurrentUser, "Login", $"User {Session.CurrentUser.Username} logged in.");

                        MessageBox.Show($"Welcome, {Session.CurrentUser.Username}!", "Login Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Redirect to Dashboard based on role
                        Dashboard dashboard = new Dashboard();
                        dashboard.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Logger.Log(0, "Login Attempt", $"Failed login attempt for username: {username}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred during login: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Logger.Log(0, "Login Error", $"Exception during login for username {username}: {ex.Message}");
            }
        }

        private void linkRegister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            RegisterForm registerForm = new RegisterForm();
            registerForm.Show();
            this.Hide();
        }
    }
}

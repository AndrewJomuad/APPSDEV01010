using System;
using System.Data.OleDb;
using System.Windows.Forms;
using OnlineClearanceSystem.Data;
using OnlineClearanceSystem.Models;

namespace OnlineClearanceSystem.Forms
{
    public partial class LogsForm : Form
    {
        public LogsForm()
        {
            InitializeComponent();
            LoadActivityLogs();
        }

        private void LoadActivityLogs()
        {
            try
            {
                dgvLogs.Rows.Clear();
                using (OleDbDataReader reader = Db.GetAllActivityLogs())
                {
                    while (reader.Read())
                    {
                        dgvLogs.Rows.Add(reader["Id"], reader["UserId"], reader["Action"], reader["Description"], reader["DateCreated"]);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading activity logs: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Logger.Log(Session.CurrentUser, "Error", $"Error loading activity logs: {ex.Message}");
            }
        }
    }
}

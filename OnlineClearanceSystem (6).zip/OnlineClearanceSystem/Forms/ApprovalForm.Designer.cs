namespace OnlineClearanceSystem.Forms
{
    partial class ApprovalForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.dgvRequests = new System.Windows.Forms.DataGridView();
            this.RequestIdColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StudentNameColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateFiledColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RequestStatusColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblRequests = new System.Windows.Forms.Label();
            this.dgvSteps = new System.Windows.Forms.DataGridView();
            this.StepIdColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OfficeColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StepStatusColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RemarksColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblSteps = new System.Windows.Forms.Label();
            this.btnApprove = new System.Windows.Forms.Button();
            this.btnReject = new System.Windows.Forms.Button();
            this.lblRemarks = new System.Windows.Forms.Label();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequests)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSteps)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(12, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(159, 25);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Approval Central";
            // 
            // dgvRequests
            // 
            this.dgvRequests.AllowUserToAddRows = false;
            this.dgvRequests.AllowUserToDeleteRows = false;
            this.dgvRequests.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRequests.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.RequestIdColumn,
            this.StudentNameColumn,
            this.DateFiledColumn,
            this.RequestStatusColumn});
            this.dgvRequests.Location = new System.Drawing.Point(12, 70);
            this.dgvRequests.MultiSelect = false;
            this.dgvRequests.Name = "dgvRequests";
            this.dgvRequests.ReadOnly = true;
            this.dgvRequests.RowTemplate.Height = 25;
            this.dgvRequests.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRequests.Size = new System.Drawing.Size(450, 200);
            this.dgvRequests.TabIndex = 1;
            this.dgvRequests.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRequests_CellClick);
            // 
            // RequestIdColumn
            // 
            this.RequestIdColumn.HeaderText = "Request ID";
            this.RequestIdColumn.Name = "RequestIdColumn";
            this.RequestIdColumn.ReadOnly = true;
            this.RequestIdColumn.Width = 80;
            // 
            // StudentNameColumn
            // 
            this.StudentNameColumn.HeaderText = "Student Name";
            this.StudentNameColumn.Name = "StudentNameColumn";
            this.StudentNameColumn.ReadOnly = true;
            this.StudentNameColumn.Width = 150;
            // 
            // DateFiledColumn
            // 
            this.DateFiledColumn.HeaderText = "Date Filed";
            this.DateFiledColumn.Name = "DateFiledColumn";
            this.DateFiledColumn.ReadOnly = true;
            this.DateFiledColumn.Width = 120;
            // 
            // RequestStatusColumn
            // 
            this.RequestStatusColumn.HeaderText = "Status";
            this.RequestStatusColumn.Name = "RequestStatusColumn";
            this.RequestStatusColumn.ReadOnly = true;
            // 
            // lblRequests
            // 
            this.lblRequests.AutoSize = true;
            this.lblRequests.Location = new System.Drawing.Point(12, 50);
            this.lblRequests.Name = "lblRequests";
            this.lblRequests.Size = new System.Drawing.Size(100, 15);
            this.lblRequests.TabIndex = 2;
            this.lblRequests.Text = "Pending Requests:";
            // 
            // dgvSteps
            // 
            this.dgvSteps.AllowUserToAddRows = false;
            this.dgvSteps.AllowUserToDeleteRows = false;
            this.dgvSteps.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSteps.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.StepIdColumn,
            this.OfficeColumn,
            this.StepStatusColumn,
            this.RemarksColumn});
            this.dgvSteps.Location = new System.Drawing.Point(480, 70);
            this.dgvSteps.MultiSelect = false;
            this.dgvSteps.Name = "dgvSteps";
            this.dgvSteps.ReadOnly = true;
            this.dgvSteps.RowTemplate.Height = 25;
            this.dgvSteps.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSteps.Size = new System.Drawing.Size(450, 200);
            this.dgvSteps.TabIndex = 3;
            // 
            // StepIdColumn
            // 
            this.StepIdColumn.HeaderText = "Step ID";
            this.StepIdColumn.Name = "StepIdColumn";
            this.StepIdColumn.ReadOnly = true;
            this.StepIdColumn.Visible = false;
            // 
            // OfficeColumn
            // 
            this.OfficeColumn.HeaderText = "Office";
            this.OfficeColumn.Name = "OfficeColumn";
            this.OfficeColumn.ReadOnly = true;
            this.OfficeColumn.Width = 120;
            // 
            // StepStatusColumn
            // 
            this.StepStatusColumn.HeaderText = "Status";
            this.StepStatusColumn.Name = "StepStatusColumn";
            this.StepStatusColumn.ReadOnly = true;
            // 
            // RemarksColumn
            // 
            this.RemarksColumn.HeaderText = "Remarks";
            this.RemarksColumn.Name = "RemarksColumn";
            this.RemarksColumn.ReadOnly = true;
            this.RemarksColumn.Width = 150;
            // 
            // lblSteps
            // 
            this.lblSteps.AutoSize = true;
            this.lblSteps.Location = new System.Drawing.Point(480, 50);
            this.lblSteps.Name = "lblSteps";
            this.lblSteps.Size = new System.Drawing.Size(84, 15);
            this.lblSteps.TabIndex = 4;
            this.lblSteps.Text = "Request Steps:";
            // 
            // btnApprove
            // 
            this.btnApprove.Location = new System.Drawing.Point(480, 320);
            this.btnApprove.Name = "btnApprove";
            this.btnApprove.Size = new System.Drawing.Size(75, 23);
            this.btnApprove.TabIndex = 5;
            this.btnApprove.Text = "Approve";
            this.btnApprove.UseVisualStyleBackColor = true;
            this.btnApprove.Click += new System.EventHandler(this.btnApprove_Click);
            // 
            // btnReject
            // 
            this.btnReject.Location = new System.Drawing.Point(561, 320);
            this.btnReject.Name = "btnReject";
            this.btnReject.Size = new System.Drawing.Size(75, 23);
            this.btnReject.TabIndex = 6;
            this.btnReject.Text = "Reject";
            this.btnReject.UseVisualStyleBackColor = true;
            this.btnReject.Click += new System.EventHandler(this.btnReject_Click);
            // 
            // lblRemarks
            // 
            this.lblRemarks.AutoSize = true;
            this.lblRemarks.Location = new System.Drawing.Point(480, 285);
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.Size = new System.Drawing.Size(55, 15);
            this.lblRemarks.TabIndex = 7;
            this.lblRemarks.Text = "Remarks:";
            // 
            // txtRemarks
            // 
            this.txtRemarks.Location = new System.Drawing.Point(541, 282);
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(389, 23);
            this.txtRemarks.TabIndex = 8;
            // 
            // ApprovalForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 360);
            this.Controls.Add(this.txtRemarks);
            this.Controls.Add(this.lblRemarks);
            this.Controls.Add(this.btnReject);
            this.Controls.Add(this.btnApprove);
            this.Controls.Add(this.lblSteps);
            this.Controls.Add(this.dgvSteps);
            this.Controls.Add(this.lblRequests);
            this.Controls.Add(this.dgvRequests);
            this.Controls.Add(this.lblTitle);
            this.Name = "ApprovalForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Approval Form";
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequests)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSteps)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.DataGridView dgvRequests;
        private System.Windows.Forms.Label lblRequests;
        private System.Windows.Forms.DataGridView dgvSteps;
        private System.Windows.Forms.Label lblSteps;
        private System.Windows.Forms.Button btnApprove;
        private System.Windows.Forms.Button btnReject;
        private System.Windows.Forms.Label lblRemarks;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn RequestIdColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn StudentNameColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateFiledColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn RequestStatusColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn StepIdColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn OfficeColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn StepStatusColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn RemarksColumn;
    }
}

namespace OnlineClearanceSystem.Models
{
    public class Subject
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string SubjectName { get; set; }
        public string Status { get; set; }
    }
}

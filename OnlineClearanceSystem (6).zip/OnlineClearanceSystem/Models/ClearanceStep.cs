namespace OnlineClearanceSystem.Models
{
    public class ClearanceStep
    {
        public int Id { get; set; }
        public int RequestId { get; set; }
        public string Office { get; set; }
        public string Status { get; set; }
        public string Remarks { get; set; }
    }
}

using System;

namespace OnlineClearanceSystem.Models
{
    public class ClearanceRequest
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public DateTime DateFiled { get; set; }
        public string Status { get; set; }
    }
}

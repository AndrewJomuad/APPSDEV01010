using System;
using System.Data.OleDb;
using OnlineClearanceSystem.Models;

namespace OnlineClearanceSystem.Data
{
    public class Logger
    {
        public static void Log(int userId, string action, string description)
        {
            try
            {
                Db.LogActivity(userId, action, description);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error logging activity: {ex.Message}");
            }
        }

        public static void Log(User user, string action, string description)
        {
            if (user != null)
            {
                Log(user.Id, action, description);
            }
            else
            {
                Log(0, action, description); // Log with a dummy user ID if user is null
            }
        }
    }
}

using System.Data.OleDb;
using System.Collections.Generic;

namespace OnlineClearanceSystem.Data
{
    public class Db
    {
        // Example: Get user by username and password
        public static OleDbDataReader GetUser(string username, string password)
        {
            string query = "SELECT * FROM Users WHERE Username = ? AND Password = ?";
            OleDbParameter[] parameters = new OleDbParameter[]
            {
                new OleDbParameter("@p1", username),
                new OleDbParameter("@p2", password)
            };
            return DbHelper.ExecuteReader(query, parameters);
        }

        // Example: Register a new student user
        public static int RegisterUser(string username, string password, string fullName, string course)
        {
            string query = "INSERT INTO Users (Username, Password, Role, FullName, Course) VALUES (?, ?, ?, ?, ?)";
            OleDbParameter[] parameters = new OleDbParameter[]
            {
                new OleDbParameter("@p1", username),
                new OleDbParameter("@p2", password),
                new OleDbParameter("@p3", "Student"),
                new OleDbParameter("@p4", fullName),
                new OleDbParameter("@p5", course)
            };
            return DbHelper.ExecuteNonQuery(query, parameters);
        }

        // Example: Log activity
        public static int LogActivity(int userId, string action, string description)
        {
            string query = "INSERT INTO ActivityLogs (UserId, Action, Description, DateCreated) VALUES (?, ?, ?, ?)";
            OleDbParameter[] parameters = new OleDbParameter[]
            {
                new OleDbParameter("@p1", userId),
                new OleDbParameter("@p2", action),
                new OleDbParameter("@p3", description),
                new OleDbParameter("@p4", System.DateTime.Now)
            };
            return DbHelper.ExecuteNonQuery(query, parameters);
        }

        // Add more database operations as needed for other tables (ClearanceRequests, ClearanceSteps, Subjects, ActivityLogs)
        // For example, methods to insert, update, and retrieve data for each entity.

        // Get all users (for AdminForm)
        public static OleDbDataReader GetAllUsers()
        {
            string query = "SELECT Id, Username, Role, FullName, Course FROM Users";
            return DbHelper.ExecuteReader(query);
        }

        // Get all activity logs (for LogsForm)
        public static OleDbDataReader GetAllActivityLogs()
        {
            string query = "SELECT * FROM ActivityLogs ORDER BY DateCreated DESC";
            return DbHelper.ExecuteReader(query);
        }

        // Insert a new clearance request
        public static int InsertClearanceRequest(int userId)
        {
            string query = "INSERT INTO ClearanceRequests (UserId, DateFiled, Status) VALUES (?, ?, ?)";
            OleDbParameter[] parameters = new OleDbParameter[]
            {
                new OleDbParameter("@p1", userId),
                new OleDbParameter("@p2", System.DateTime.Now),
                new OleDbParameter("@p3", "Pending")
            };
            return DbHelper.ExecuteNonQuery(query, parameters);
        }

        // Get the last inserted ID for ClearanceRequests
        public static int GetLastClearanceRequestId()
        {
            string query = "SELECT @@IDENTITY";
            return (int)DbHelper.ExecuteScalar(query);
        }

        // Insert clearance steps for a request
        public static int InsertClearanceStep(int requestId, string office, string status)
        {
            string query = "INSERT INTO ClearanceSteps (RequestId, Office, Status, Remarks) VALUES (?, ?, ?, ?)";
            OleDbParameter[] parameters = new OleDbParameter[]
            {
                new OleDbParameter("@p1", requestId),
                new OleDbParameter("@p2", office),
                new OleDbParameter("@p3", status),
                new OleDbParameter("@p4", "") // Initial empty remarks
            };
            return DbHelper.ExecuteNonQuery(query, parameters);
        }

        // Get clearance requests for a specific office
        public static OleDbDataReader GetClearanceRequestsForOffice(string office)
        {
            string query = "SELECT CR.Id, U.FullName, CR.DateFiled, CR.Status FROM ClearanceRequests AS CR INNER JOIN Users AS U ON CR.UserId = U.Id INNER JOIN ClearanceSteps AS CS ON CR.Id = CS.RequestId WHERE CS.Office = ? AND CS.Status = ?";
            OleDbParameter[] parameters = new OleDbParameter[]
            {
                new OleDbParameter("@p1", office),
                new OleDbParameter("@p2", "Pending")
            };
            return DbHelper.ExecuteReader(query, parameters);
        }

        // Update clearance step status and remarks
        public static int UpdateClearanceStep(int stepId, string status, string remarks)
        {
            string query = "UPDATE ClearanceSteps SET Status = ?, Remarks = ? WHERE Id = ?";
            OleDbParameter[] parameters = new OleDbParameter[]
            {
                new OleDbParameter("@p1", status),
                new OleDbParameter("@p2", remarks),
                new OleDbParameter("@p3", stepId)
            };
            return DbHelper.ExecuteNonQuery(query, parameters);
        }

        // Get clearance steps for a request
        public static OleDbDataReader GetClearanceStepsByRequestId(int requestId)
        {
            string query = "SELECT * FROM ClearanceSteps WHERE RequestId = ? ORDER BY Id ASC";
            OleDbParameter[] parameters = new OleDbParameter[]
            {
                new OleDbParameter("@p1", requestId)
            };
            return DbHelper.ExecuteReader(query, parameters);
        }

        // Update ClearanceRequest status
        public static int UpdateClearanceRequestStatus(int requestId, string status)
        {
            string query = "UPDATE ClearanceRequests SET Status = ? WHERE Id = ?";
            OleDbParameter[] parameters = new OleDbParameter[]
            {
                new OleDbParameter("@p1", status),
                new OleDbParameter("@p2", requestId)
            };
            return DbHelper.ExecuteNonQuery(query, parameters);
        }

        // Insert a new subject
        public static int InsertSubject(int userId, string subjectName)
        {
            string query = "INSERT INTO Subjects (UserId, SubjectName, Status) VALUES (?, ?, ?)";
            OleDbParameter[] parameters = new OleDbParameter[]
            {
                new OleDbParameter("@p1", userId),
                new OleDbParameter("@p2", subjectName),
                new OleDbParameter("@p3", "Pending")
            };
            return DbHelper.ExecuteNonQuery(query, parameters);
        }

        // Get subjects by user ID
        public static OleDbDataReader GetSubjectsByUserId(int userId)
        {
            string query = "SELECT * FROM Subjects WHERE UserId = ?";
            OleDbParameter[] parameters = new OleDbParameter[]
            {
                new OleDbParameter("@p1", userId)
            };
            return DbHelper.ExecuteReader(query, parameters);
        }

        // Update subject status
        public static int UpdateSubjectStatus(int subjectId, string status)
        {
            string query = "UPDATE Subjects SET Status = ? WHERE Id = ?";
            OleDbParameter[] parameters = new OleDbParameter[]
            {
                new OleDbParameter("@p1", status),
                new OleDbParameter("@p2", subjectId)
            };
            return DbHelper.ExecuteNonQuery(query, parameters);
        }

        // Get user by ID
        public static OleDbDataReader GetUserById(int userId)
        {
            string query = "SELECT * FROM Users WHERE Id = ?";
            OleDbParameter[] parameters = new OleDbParameter[]
            {
                new OleDbParameter("@p1", userId)
            };
            return DbHelper.ExecuteReader(query, parameters);
        }

        // Delete user by ID
        public static int DeleteUser(int userId)
        {
            string query = "DELETE FROM Users WHERE Id = ?";
            OleDbParameter[] parameters = new OleDbParameter[]
            {
                new OleDbParameter("@p1", userId)
            };
            return DbHelper.ExecuteNonQuery(query, parameters);
        }
    }
}

using System.Data.OleDb;
using System.IO;
using System.Windows.Forms;

namespace OnlineClearanceSystem.Data
{
    public class DbHelper
    {
        private static string ConnectionString
        {
            get
            {
                string dbPath = Path.Combine(Application.StartupPath, "Database", "ClearanceDB.accdb");
                return $"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={dbPath};Persist Security Info=False;";
            }
        }

        public static OleDbConnection GetConnection()
        {
            return new OleDbConnection(ConnectionString);
        }

        public static int ExecuteNonQuery(string query, OleDbParameter[] parameters = null)
        {
            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    return command.ExecuteNonQuery();
                }
            }
        }

        public static OleDbDataReader ExecuteReader(string query, OleDbParameter[] parameters = null)
        {
            OleDbConnection connection = GetConnection();
            connection.Open();
            OleDbCommand command = new OleDbCommand(query, connection);
            if (parameters != null)
            {
                command.Parameters.AddRange(parameters);
            }
            return command.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
        }

        public static object ExecuteScalar(string query, OleDbParameter[] parameters = null)
        {
            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }
                    return command.ExecuteScalar();
                }
            }
        }
    }
}
